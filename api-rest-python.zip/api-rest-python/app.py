from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///usuarios.db'
db = SQLAlchemy(app)

class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(50), nullable=False)
    apellido = db.Column(db.String(50), nullable=False)
    telefono = db.Column(db.String(10), nullable=False)
    email = db.Column(db.String(50), nullable=False)

    def serialize(self):
        return{
            'id': self.id,
            'nombre': self.nombre,
            'apellido': self.apellido,
            'telefono': self.telefono,
            'email': self.email
        }
    
with app.app_context():
    db.create_all()

#Listar todos los usuarios
@app.route('/usuarios', methods=['GET'])
def listar():
    usuarios = Usuario.query.all()
    return jsonify({'usuarios': [i.serialize() for i in usuarios]})

#Agregar un usuario
@app.route('/usuarios', methods=['POST'])
def agregar():
    datos = request.get_json()
    usuario = Usuario(nombre = datos['nombre'], apellido = datos['apellido'], telefono = datos['telefono'], email = datos['email'])
    db.session.add(usuario)
    db.session.commit()
    return jsonify({'mensaje': 'Registro exitoso', 'usuario': usuario.serialize()})

#Listar un usuario obteniendo su id
@app.route('/usuarios/<int:id>', methods=['GET'])
def listarPorId(id):
    usuario = Usuario.query.get(id)
    if not usuario:
        return jsonify({'mensaje': 'Registro no existe'})
    return jsonify(usuario.serialize())

#Actualizar un usuario
@app.route('/usuarios/<int:id>', methods=['PUT', 'PATCH'])
def actualizar(id):
    usuario = Usuario.query.get(id)
    datos = request.get_json()
    if 'nombre' in datos:
        usuario.nombre = datos['nombre']
    if 'apellido' in datos:
        usuario.apellido = datos['apellido']
    if 'telefono' in datos:
        usuario.telefono = datos['telefono']
    if 'email' in datos:
        usuario.email = datos['email']
    db.session.commit()
    return jsonify({'mensaje': 'Registro actualizado con éxito', 'usuario': usuario.serialize()})

#Eliminar un usuario
@app.route('/usuarios/<int:id>', methods=['DELETE'])
def eliminar(id):
    usuario = Usuario.query.get(id)
    if not usuario:
        return jsonify({'mensaje': 'Registro no existe'})
    db.session.delete(usuario)
    db.session.commit()
    return jsonify({'mensaje': 'Registro eliminado'})